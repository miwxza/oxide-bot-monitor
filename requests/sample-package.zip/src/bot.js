console.log("oxide bot sample")
